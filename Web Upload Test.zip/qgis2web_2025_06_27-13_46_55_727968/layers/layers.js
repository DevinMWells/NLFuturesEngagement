var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_QGISLocationsforEngagementSessions_1 = new ol.format.GeoJSON();
var features_QGISLocationsforEngagementSessions_1 = format_QGISLocationsforEngagementSessions_1.readFeatures(json_QGISLocationsforEngagementSessions_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_QGISLocationsforEngagementSessions_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_QGISLocationsforEngagementSessions_1.addFeatures(features_QGISLocationsforEngagementSessions_1);
var lyr_QGISLocationsforEngagementSessions_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_QGISLocationsforEngagementSessions_1, 
                style: style_QGISLocationsforEngagementSessions_1,
                popuplayertitle: 'QGIS Locations for Engagement Sessions',
                interactive: true,
                title: '<img src="styles/legend/QGISLocationsforEngagementSessions_1.png" /> QGIS Locations for Engagement Sessions'
            });

lyr_OpenStreetMap_0.setVisible(true);lyr_QGISLocationsforEngagementSessions_1.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_QGISLocationsforEngagementSessions_1];
lyr_QGISLocationsforEngagementSessions_1.set('fieldAliases', {'Organization Name': 'Organization Name', 'Location Name': 'Location Name', 'Date': 'Date', 'Latitude': 'Latitude', 'Longitude': 'Longitude', });
lyr_QGISLocationsforEngagementSessions_1.set('fieldImages', {'Organization Name': 'TextEdit', 'Location Name': 'TextEdit', 'Date': 'TextEdit', 'Latitude': 'TextEdit', 'Longitude': 'TextEdit', });
lyr_QGISLocationsforEngagementSessions_1.set('fieldLabels', {'Organization Name': 'inline label - visible with data', 'Location Name': 'inline label - visible with data', 'Date': 'no label', 'Latitude': 'hidden field', 'Longitude': 'hidden field', });
lyr_QGISLocationsforEngagementSessions_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});